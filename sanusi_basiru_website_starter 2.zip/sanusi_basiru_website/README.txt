SANUSI BASIRU LTD — Website starter

Files:
- index.html: responsive one-page website draft.

Before publishing:
1. Confirm that you are legally entitled to use the company name "SANUSI BASIRU LTD".
2. Replace the founder portrait placeholder with a photo you choose.
3. Add a professional email address and any verified contact details.
4. Add only genuine, dated articles and accurate author credits.
5. Check and register the domain sanusibasirultd.com if it is available.
6. Choose a hosting provider and upload index.html to the website's public web root.

This is a website draft, not a live registered domain or hosted website.
